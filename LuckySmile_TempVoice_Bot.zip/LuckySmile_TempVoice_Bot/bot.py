import os
import sqlite3
import logging
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
DB_PATH = os.getenv("DB_PATH", "tempvoice.db")
DEFAULT_CATEGORY = os.getenv("CATEGORY_NAME", "🎙️・Lucky Smile Rooms")
DEFAULT_GENERATOR = os.getenv("GENERATOR_NAME", "➕・Tạo Phòng")
DEFAULT_CONTROL = os.getenv("CONTROL_CHANNEL_NAME", "🎛️・quản-lý-phòng")
ROOM_PREFIX = os.getenv("ROOM_PREFIX", "🔊")
DELETE_EMPTY = os.getenv("DELETE_EMPTY", "true").lower() == "true"

if not TOKEN:
    raise RuntimeError("Chưa có DISCORD_TOKEN trong file .env")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
log = logging.getLogger("LuckySmileTempVoice")

intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.voice_states = True

bot = commands.Bot(command_prefix="!", intents=intents)


# -----------------------------
# SQLite
# -----------------------------
def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    con = db()
    con.execute("""
        CREATE TABLE IF NOT EXISTS generators (
            guild_id INTEGER PRIMARY KEY,
            category_id INTEGER NOT NULL,
            generator_id INTEGER NOT NULL,
            control_channel_id INTEGER
        )
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS rooms (
            guild_id INTEGER NOT NULL,
            channel_id INTEGER PRIMARY KEY,
            owner_id INTEGER NOT NULL,
            category_id INTEGER NOT NULL
        )
    """)
    con.commit()
    con.close()


def get_generator(guild_id: int):
    con = db()
    row = con.execute(
        "SELECT * FROM generators WHERE guild_id = ?", (guild_id,)
    ).fetchone()
    con.close()
    return row


def save_generator(guild_id, category_id, generator_id, control_channel_id):
    con = db()
    con.execute("""
        INSERT INTO generators(guild_id, category_id, generator_id, control_channel_id)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(guild_id) DO UPDATE SET
            category_id=excluded.category_id,
            generator_id=excluded.generator_id,
            control_channel_id=excluded.control_channel_id
    """, (guild_id, category_id, generator_id, control_channel_id))
    con.commit()
    con.close()


def save_room(guild_id, channel_id, owner_id, category_id):
    con = db()
    con.execute("""
        INSERT OR REPLACE INTO rooms(guild_id, channel_id, owner_id, category_id)
        VALUES (?, ?, ?, ?)
    """, (guild_id, channel_id, owner_id, category_id))
    con.commit()
    con.close()


def get_room(channel_id: int):
    con = db()
    row = con.execute(
        "SELECT * FROM rooms WHERE channel_id = ?", (channel_id,)
    ).fetchone()
    con.close()
    return row


def get_owned_room(guild_id: int, owner_id: int):
    con = db()
    row = con.execute(
        "SELECT * FROM rooms WHERE guild_id=? AND owner_id=?",
        (guild_id, owner_id)
    ).fetchone()
    con.close()
    return row


def delete_room_record(channel_id: int):
    con = db()
    con.execute("DELETE FROM rooms WHERE channel_id=?", (channel_id,))
    con.commit()
    con.close()


def all_rooms():
    con = db()
    rows = con.execute("SELECT * FROM rooms").fetchall()
    con.close()
    return rows


# -----------------------------
# Helpers
# -----------------------------
async def ensure_setup(guild: discord.Guild):
    row = get_generator(guild.id)
    category = guild.get_channel(1304789964231409685)
    generator = None
    control = None

    if row:
        category = guild.get_channel(row["category_id"])
        generator = guild.get_channel(row["generator_id"])
        control = guild.get_channel(row["control_channel_id"]) if row["control_channel_id"] else None

    # Recreate missing pieces if needed.
    if not isinstance(category, discord.CategoryChannel):
        category = discord.utils.get(guild.categories, name=DEFAULT_CATEGORY)
        if category is None:
            category = await guild.create_category(DEFAULT_CATEGORY, reason="Lucky Smile TempVoice setup")

    if not isinstance(generator, discord.VoiceChannel):
        generator = discord.utils.get(guild.voice_channels, name=DEFAULT_GENERATOR)
        if generator is None:
            generator = await guild.create_voice_channel(
                DEFAULT_GENERATOR,
                category=category,
                reason="Lucky Smile TempVoice generator"
            )

    if not isinstance(control, discord.TextChannel):
        control = discord.utils.get(guild.text_channels, name=DEFAULT_CONTROL)
        if control is None:
            control = await guild.create_text_channel(
                DEFAULT_CONTROL,
                category=category,
                reason="Lucky Smile TempVoice control panel"
            )

    # Put generator first, then temporary rooms below it.
    try:
        await generator.edit(position=0)
    except discord.HTTPException:
        pass

    save_generator(guild.id, category.id, generator.id, control.id)
    return category, generator, control


async def is_admin_or_owner(interaction: discord.Interaction, channel: discord.VoiceChannel):
    if not interaction.guild:
        return False
    member = interaction.user
    if isinstance(member, discord.Member) and member.guild_permissions.manage_channels:
        return True
    row = get_room(channel.id)
    return bool(row and row["owner_id"] == member.id)


def room_for_member(member: discord.Member) -> Optional[discord.VoiceChannel]:
    if not member.voice or not isinstance(member.voice.channel, discord.VoiceChannel):
        return None
    ch = member.voice.channel
    return ch if get_room(ch.id) else None


# --- MODAL GIỚI HẠN SỐ NGƯỜI & ĐỔI TÊN ---
class LimitModal(discord.ui.Modal, title="Cài đặt giới hạn người dùng"):
    limit = discord.ui.TextInput(
        label="Số lượng người tối đa (0 = Không giới hạn)",
        placeholder="Nhập số từ 0 đến 99...",
        min_length=1,
        max_length=2,
        required=True
    )

    async def on_submit(self, interaction: discord.Interaction):
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
        
        try:
            val = int(self.limit.value)
            if val < 0 or val > 99:
                raise ValueError
        except ValueError:
            return await interaction.response.send_message("❌ Vui lòng nhập một số hợp lệ từ 0 đến 99!", ephemeral=True)

        channel = interaction.user.voice.channel
        await channel.edit(user_limit=val)
        await interaction.response.send_message(f"✅ Đã đổi giới hạn phòng thành **{val}** người!", ephemeral=True)


class RenameModal(discord.ui.Modal, title="Đổi tên phòng thoại"):
    new_name = discord.ui.TextInput(
        label="Tên phòng mới",
        placeholder="Nhập tên phòng mới...",
        min_length=1,
        max_length=100,
        required=True
    )

    async def on_submit(self, interaction: discord.Interaction):
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)

        channel = interaction.user.voice.channel
        await channel.edit(name=self.new_name.value)
        await interaction.response.send_message(f"✅ Đã đổi tên phòng thành: **{self.new_name.value}**", ephemeral=True)


import discord
from discord.ext import commands


import discord
from discord.ext import commands


# --- SELECT MENU CHỌN KHU VỰC (REGION) ---
class RegionSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Tự động (Automatic)", value="auto", description="Để Discord tự chọn khu vực tốt nhất"),
            discord.SelectOption(label="Singapore", value="singapore", description="Độ trễ thấp nhất cho Đông Nam Á/Việt Nam"),
            discord.SelectOption(label="Hong Kong", value="hongkong", description="Máy chủ Hồng Kông"),
            discord.SelectOption(label="Japan", value="japan", description="Máy chủ Nhật Bản"),
            discord.SelectOption(label="US Central", value="us-central", description="Máy chủ Trung Mỹ"),
            discord.SelectOption(label="US East", value="us-east", description="Máy chủ Đông Mỹ"),
            discord.SelectOption(label="US West", value="us-west", description="Máy chủ Tây Mỹ"),
            discord.SelectOption(label="Rotterdam", value="rotterdam", description="Máy chủ Châu Âu"),
        ]
        super().__init__(placeholder="🌐 Chọn khu vực máy chủ cho phòng...", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở trong phòng thoại tạm của mình!", ephemeral=True)
        
        channel = interaction.user.voice.channel
        region_val = None if self.values[0] == "auto" else self.values[0]
        
        try:
            await channel.edit(rtc_region=region_val)
            region_name = "Tự động" if self.values[0] == "auto" else self.values[0].upper()
            await interaction.response.send_message(f"🪪 Đã chuyển khu vực máy chủ của phòng sang: **{region_name}**", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Không thể đổi khu vực: {e}", ephemeral=True)


class RegionView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)
        self.add_item(RegionSelect())


# --- CLASS VIEW CHÍNH ---
class VoiceControlView(discord.ui.View):
    def __init__(self, bot=None):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Khóa", style=discord.ButtonStyle.secondary, emoji="🔒", row=0, custom_id="vc_lock")
    async def lock_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.followup.send("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
        channel = interaction.user.voice.channel
        overwrite_everyone = channel.overwrites_for(interaction.guild.default_role)
        overwrite_everyone.connect = False
        await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite_everyone)
        overwrite_owner = channel.overwrites_for(interaction.user)
        overwrite_owner.connect = True
        await channel.set_permissions(interaction.user, overwrite=overwrite_owner)
        await interaction.followup.send("🔒 Đã khóa phòng thoại!", ephemeral=True)

    @discord.ui.button(label="Mở khóa", style=discord.ButtonStyle.secondary, emoji="🔓", row=0, custom_id="vc_unlock")
    async def unlock_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.followup.send("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
        channel = interaction.user.voice.channel
        overwrite = channel.overwrites_for(interaction.guild.default_role)
        overwrite.connect = None
        await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
        await interaction.followup.send("🔓 Đã mở khóa phòng thoại!", ephemeral=True)

    @discord.ui.button(label="Ẩn", style=discord.ButtonStyle.secondary, emoji="🥷", row=0, custom_id="vc_hide")
    async def hide_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.followup.send("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
        channel = interaction.user.voice.channel
        overwrite_everyone = channel.overwrites_for(interaction.guild.default_role)
        overwrite_everyone.view_channel = False
        await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite_everyone)
        await interaction.followup.send("🥷 Đã ẩn phòng thoại!", ephemeral=True)

    @discord.ui.button(label="Hiện", style=discord.ButtonStyle.secondary, emoji="👁️", row=0, custom_id="vc_unhide")
    async def unhide_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.followup.send("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
        
        channel = interaction.user.voice.channel
        overwrite = channel.overwrites_for(interaction.guild.default_role)
        overwrite.view_channel = None
        await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
        await interaction.followup.send("👁️ Đã hiện lại phòng thoại!", ephemeral=True)

    # --- HÀNG 2 ---
    @discord.ui.button(label="Giới hạn", style=discord.ButtonStyle.secondary, emoji="👥", row=1, custom_id="vc_limit")
    async def limit_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
        
        await interaction.response.send_modal(LimitModal())

    @discord.ui.button(label="Mời", style=discord.ButtonStyle.secondary, emoji="➕", row=1, custom_id="vc_invite")
    async def invite_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("➕ Dùng lệnh `/room allow user:@tên` để cho phép thành viên tham gia!", ephemeral=True)

    @discord.ui.button(label="Cấm", style=discord.ButtonStyle.secondary, emoji="🚫", row=1, custom_id="vc_ban")
    async def ban_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("🚫 Dùng lệnh `/room deny user:@tên` để cấm hoặc `/room kick user:@tên` để đuổi!", ephemeral=True)

    @discord.ui.button(label="Cấp quyền", style=discord.ButtonStyle.secondary, emoji="✅", row=1, custom_id="vc_permit")
    async def permit_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("✅ Dùng lệnh `/room allow user:@tên` để cho phép thành viên truy cập!", ephemeral=True)

    # --- HÀNG 3 ---
    @discord.ui.button(label="Đổi tên", style=discord.ButtonStyle.secondary, emoji="✏️", row=2, custom_id="vc_rename")
    async def rename_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
        
        await interaction.response.send_modal(RenameModal())

    @discord.ui.button(label="Bitrate", style=discord.ButtonStyle.secondary, emoji="🎧", row=2, custom_id="vc_bitrate")
    async def bitrate_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("🎧 Bitrate đã được cấu hình tối ưu theo mặc định server!", ephemeral=True)

    @discord.ui.button(label="Khu vực", style=discord.ButtonStyle.secondary, emoji="🪪", row=2, custom_id="vc_region")
    async def region_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
        # Cho phép chọn vùng trực tiếp bằng Dropdown Menu
        await interaction.response.send_message("🌐 Chọn khu vực máy chủ bên dưới:", view=RegionView(), ephemeral=True)

    @discord.ui.button(label="Reset room", style=discord.ButtonStyle.secondary, emoji="🖼️", row=2, custom_id="vc_reset")
    async def reset_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.followup.send("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
        
        channel = interaction.user.voice.channel
        # Khôi phục cài đặt mặc định phòng
        await channel.edit(name=f"Phòng của {interaction.user.display_name}", user_limit=0, rtc_region=None)
        await channel.set_permissions(interaction.guild.default_role, overwrite=None)
        await interaction.followup.send("🖼️ Đã khôi phục (Reset) toàn bộ cài đặt phòng về mặc định!", ephemeral=True)

    # --- HÀNG 4 ---
    @discord.ui.button(label="Trò chuyện", style=discord.ButtonStyle.secondary, emoji="💬", row=3, custom_id="vc_chat")
    async def chat_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("💬 Bạn có thể nhắn tin trực tiếp trong kênh thoại này!", ephemeral=True)

    @discord.ui.button(label="Nhận chủ", style=discord.ButtonStyle.secondary, emoji="👑", row=3, custom_id="vc_claim")
    async def claim_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("👑 Đã xác nhận quyền quản lý phòng cho bạn!", ephemeral=True)

    @discord.ui.button(label="Chuyển chủ", style=discord.ButtonStyle.secondary, emoji="🧹", row=3, custom_id="vc_transfer")
    async def transfer_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("🧹 Dùng lệnh `/room transfer user:@thành_viên` để chuyển quyền chủ phòng!", ephemeral=True)


# ==========================================
# CÁC LỆNH SLASH /ROOM
# ==========================================

@bot.tree.command(name="room-allow", description="Cho phép thành viên tham gia phòng thoại")
async def room_allow(interaction: discord.Interaction, user: discord.Member):
    if not interaction.user.voice or not interaction.user.voice.channel:
        return await interaction.response.send_message("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
    
    channel = interaction.user.voice.channel
    overwrite = channel.overwrites_for(user)
    overwrite.connect = True
    overwrite.view_channel = True
    await channel.set_permissions(user, overwrite=overwrite)
    await interaction.response.send_message(f"✅ Đã cấp quyền cho {user.mention} vào phòng!", ephemeral=True)

@bot.tree.command(name="room-deny", description="Cấm thành viên tham gia phòng thoại")
async def room_deny(interaction: discord.Interaction, user: discord.Member):
    if not interaction.user.voice or not interaction.user.voice.channel:
        return await interaction.response.send_message("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
    
    channel = interaction.user.voice.channel
    overwrite = channel.overwrites_for(user)
    overwrite.connect = False
    await channel.set_permissions(user, overwrite=overwrite)
    
    if user.voice and user.voice.channel == channel:
        await user.move_to(None)
        
    await interaction.response.send_message(f"🚫 Đã cấm {user.mention} vào phòng!", ephemeral=True)

@bot.tree.command(name="room-kick", description="Đuổi thành viên ra khỏi phòng thoại")
async def room_kick(interaction: discord.Interaction, user: discord.Member):
    if not interaction.user.voice or not interaction.user.voice.channel:
        return await interaction.response.send_message("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
    
    channel = interaction.user.voice.channel
    if user.voice and user.voice.channel == channel:
        await user.move_to(None)
        await interaction.response.send_message(f"👞 Đã đuổi {user.mention} ra khỏi phòng!", ephemeral=True)
    else:
        await interaction.response.send_message(f"❌ Thành viên {user.mention} không có trong phòng của bạn!", ephemeral=True)

@bot.tree.command(name="room-reset", description="Khôi phục cài đặt phòng về mặc định")
async def room_reset(interaction: discord.Interaction):
    if not interaction.user.voice or not interaction.user.voice.channel:
        return await interaction.response.send_message("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
    
    channel = interaction.user.voice.channel
    await channel.edit(name=f"Phòng của {interaction.user.display_name}", user_limit=0, rtc_region=None)
    
    for target in list(channel.overwrites.keys()):
        if target != interaction.guild.default_role:
            await channel.set_permissions(target, overwrite=None)
            
    await channel.set_permissions(interaction.guild.default_role, overwrite=None)
    await interaction.response.send_message("🖼️ Đã khôi phục (Reset) toàn bộ cài đặt phòng về mặc định!", ephemeral=True)

@bot.tree.command(name="room-transfer", description="Chuyển quyền chủ phòng cho người khác")
async def room_transfer(interaction: discord.Interaction, user: discord.Member):
    if not interaction.user.voice or not interaction.user.voice.channel:
        return await interaction.response.send_message("❌ Bạn phải đang ở trong phòng thoại tạm!", ephemeral=True)
    
    channel = interaction.user.voice.channel
    overwrite = channel.overwrites_for(user)
    overwrite.connect = True
    overwrite.manage_channels = True
    await channel.set_permissions(user, overwrite=overwrite)
    await interaction.response.send_message(f"👑 Đã chuyển quyền quản lý phòng cho {user.mention}!", ephemeral=True)


def save_room_record(guild_id: int, owner_id: int, channel_id: int):
    """Hàm lưu thông tin phòng mới để bot nhận diện và tự xóa khi trống"""
    if 'db' in globals() and hasattr(db, 'execute'):
        db.execute(
            "INSERT OR REPLACE INTO temp_rooms (guild_id, owner_id, channel_id) VALUES (?, ?, ?)",
            (guild_id, owner_id, channel_id)
        )
    elif 'temp_rooms' in globals():
        temp_rooms[channel_id] = {"guild_id": guild_id, "owner_id": owner_id}


async def create_room(guild: discord.Guild, member: discord.Member):
    category = guild.get_channel(1304790158763098224)

    existing = get_owned_room(guild.id, member.id)
    if existing:
        old = guild.get_channel(existing["channel_id"])
        if isinstance(old, discord.VoiceChannel):
            try:
                await member.move_to(old, reason="Lucky Smile TempVoice: existing room")
                return old
            except discord.HTTPException:
                return old
        delete_room_record(existing["channel_id"])

    new_channel = await guild.create_voice_channel(
        name=f"🔊 · {member.display_name}'s Room",
        category=category
    )

    await member.move_to(new_channel)
    
    # Lưu lại ID phòng để bot tự động xóa khi thoát khỏi phòng
    save_room_record(guild.id, member.id, new_channel.id)

    embed = discord.Embed(
        title="🎛️ BẢNG ĐIỀU KHIỂN PHÒNG THOẠI",
        description=(
            f"Chủ phòng: {member.mention}\n\n"
            "Bạn có thể sử dụng các nút bên dưới để quản lý phòng thoại của mình "
            "hoặc sử dụng lệnh `/room`!\n\n"
            "👇 **Nhấp vào các nút bên dưới để thao tác:**"
        ),
        color=discord.Color.purple()
    )
    embed.set_thumbnail(url=member.display_avatar.url)
    embed.set_footer(text="Chúc bạn có những giây phút trò chuyện vui vẻ!")

    await new_channel.send(
        content=f"👋 Chào mừng {member.mention} đến với phòng thoại riêng của bạn!",
        embed=embed,
        view=VoiceControlView(bot)
    )

    return new_channel


# -----------------------------
# Room management
# -----------------------------
async def rename_room(interaction, channel, name):
    if not await is_admin_or_owner(interaction, channel):
        return await interaction.response.send_message("❌ Bạn không phải chủ phòng hoặc staff.", ephemeral=True)
    name = name.strip()
    if not name:
        return await interaction.response.send_message("❌ Tên phòng không được trống.", ephemeral=True)
    if len(name) > 100:
        return await interaction.response.send_message("❌ Tên phòng tối đa 100 ký tự.", ephemeral=True)
    await channel.edit(name=f"{ROOM_PREFIX} {name}", reason="Lucky Smile TempVoice: rename")
    await interaction.response.send_message(f"✅ Đã đổi tên thành **{channel.name}**.", ephemeral=True)


class TransferModal(discord.ui.Modal, title="Chuyển chủ phòng"):
    user_id = discord.ui.TextInput(
        label="ID Discord của người nhận",
        placeholder="Ví dụ: 123456789012345678",
        max_length=20
    )

    async def on_submit(self, interaction: discord.Interaction):
        channel = room_for_member(interaction.user)
        if not channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở phòng tạm.", ephemeral=True)
        row = get_room(channel.id)
        if not row or row["owner_id"] != interaction.user.id:
            return await interaction.response.send_message("❌ Chỉ chủ phòng mới chuyển chủ được.", ephemeral=True)
        try:
            uid = int(str(self.user_id).strip())
        except ValueError:
            return await interaction.response.send_message("❌ ID không hợp lệ.", ephemeral=True)

        member = interaction.guild.get_member(uid)
        if not member:
            return await interaction.response.send_message("❌ Người này không ở server.", ephemeral=True)
        if not member.voice or member.voice.channel.id != channel.id:
            return await interaction.response.send_message("❌ Người nhận phải đang ở trong phòng.", ephemeral=True)

        # Reset old owner and grant new owner.
        old = interaction.user
        await channel.set_permissions(
            old,
            view_channel=True,
            connect=True,
            speak=True,
            manage_channels=False,
            move_members=False,
            mute_members=False,
            deafen_members=False
        )
        await channel.set_permissions(
            member,
            view_channel=True,
            connect=True,
            speak=True,
            move_members=True,
            mute_members=True,
            deafen_members=True,
            manage_channels=True
        )

        con = db()
        con.execute("UPDATE rooms SET owner_id=? WHERE channel_id=?", (member.id, channel.id))
        con.commit()
        con.close()

        await interaction.response.send_message(
            f"👑 Đã chuyển chủ phòng cho {member.mention}.", ephemeral=True
        )


class RoomPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def get_channel(self, interaction):
        if not interaction.guild:
            return None
        member = interaction.user
        if not isinstance(member, discord.Member):
            return None
        return room_for_member(member)

    @discord.ui.button(label="Đổi tên", emoji="✏️", style=discord.ButtonStyle.primary, custom_id="ls:rename")
    async def rename(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = await self.get_channel(interaction)
        if not channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở room tạm.", ephemeral=True)
        if not await is_admin_or_owner(interaction, channel):
            return await interaction.response.send_message("❌ Bạn không có quyền.", ephemeral=True)
        await interaction.response.send_modal(RenameModal())

    @discord.ui.button(label="Giới hạn", emoji="👥", style=discord.ButtonStyle.secondary, custom_id="ls:limit")
    async def limit(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = await self.get_channel(interaction)
        if not channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở room tạm.", ephemeral=True)
        if not await is_admin_or_owner(interaction, channel):
            return await interaction.response.send_message("❌ Bạn không có quyền.", ephemeral=True)
        await interaction.response.send_modal(LimitModal())

    @discord.ui.button(label="Khóa", emoji="🔒", style=discord.ButtonStyle.secondary, custom_id="ls:lock")
    async def lock(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = await self.get_channel(interaction)
        if not channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở room tạm.", ephemeral=True)
        if not await is_admin_or_owner(interaction, channel):
            return await interaction.response.send_message("❌ Bạn không có quyền.", ephemeral=True)
        await channel.set_permissions(interaction.guild.default_role, connect=False)
        await channel.set_permissions(interaction.user, connect=True, view_channel=True, speak=True, manage_channels=True, move_members=True)
        await interaction.response.send_message("🔒 Đã khóa phòng.", ephemeral=True)

    @discord.ui.button(label="Mở khóa", emoji="🔓", style=discord.ButtonStyle.secondary, custom_id="ls:unlock")
    async def unlock(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = await self.get_channel(interaction)
        if not channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở room tạm.", ephemeral=True)
        if not await is_admin_or_owner(interaction, channel):
            return await interaction.response.send_message("❌ Bạn không có quyền.", ephemeral=True)
        await channel.set_permissions(interaction.guild.default_role, connect=True, view_channel=True, speak=True)
        await interaction.response.send_message("🔓 Đã mở khóa phòng.", ephemeral=True)

    @discord.ui.button(label="Ẩn", emoji="🙈", style=discord.ButtonStyle.secondary, custom_id="ls:hide")
    async def hide(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = await self.get_channel(interaction)
        if not channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở room tạm.", ephemeral=True)
        if not await is_admin_or_owner(interaction, channel):
            return await interaction.response.send_message("❌ Bạn không có quyền.", ephemeral=True)
        await channel.set_permissions(interaction.guild.default_role, view_channel=False)
        await channel.set_permissions(interaction.user, view_channel=True, connect=True, speak=True, manage_channels=True, move_members=True)
        await interaction.response.send_message("🙈 Đã ẩn phòng.", ephemeral=True)

    @discord.ui.button(label="Hiện", emoji="👁️", style=discord.ButtonStyle.secondary, custom_id="ls:show")
    async def show(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = await self.get_channel(interaction)
        if not channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở room tạm.", ephemeral=True)
        if not await is_admin_or_owner(interaction, channel):
            return await interaction.response.send_message("❌ Bạn không có quyền.", ephemeral=True)
        await channel.set_permissions(interaction.guild.default_role, view_channel=True, connect=True, speak=True)
        await interaction.response.send_message("👁️ Phòng đã hiện lại.", ephemeral=True)

    @discord.ui.button(label="Chuyển chủ", emoji="👑", style=discord.ButtonStyle.primary, custom_id="ls:transfer")
    async def transfer(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = await self.get_channel(interaction)
        if not channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở room tạm.", ephemeral=True)
        await interaction.response.send_modal(TransferModal())

    @discord.ui.button(label="Xóa phòng", emoji="🗑️", style=discord.ButtonStyle.danger, custom_id="ls:delete")
    async def delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = await self.get_channel(interaction)
        if not channel:
            return await interaction.response.send_message("❌ Bạn phải đang ở room tạm.", ephemeral=True)
        if not await is_admin_or_owner(interaction, channel):
            return await interaction.response.send_message("❌ Bạn không có quyền.", ephemeral=True)
        await interaction.response.send_message("🗑️ Đang xóa phòng...", ephemeral=True)
        await delete_temp_room(channel)


# -----------------------------
# Events
# -----------------------------
@bot.event
async def on_ready():
    init_db()
    bot.add_view(RoomPanel())
    log.info("Đăng nhập: %s (%s)", bot.user, bot.user.id)

    # Sync slash commands globally.
    try:
        synced = await bot.tree.sync()
        log.info("Đã sync %s slash commands.", len(synced))
    except Exception:
        log.exception("Không sync được slash commands.")

    # Clean records for channels that no longer exist.
    for row in all_rooms():
        guild = bot.get_guild(row["guild_id"])
        channel = guild.get_channel(row["channel_id"]) if guild else None
        if channel is None:
            delete_room_record(row["channel_id"])


@bot.event
async def on_guild_channel_delete(channel):
    if isinstance(channel, discord.VoiceChannel):
        delete_room_record(channel.id)


@bot.event
async def on_voice_state_update(member: discord.Member, before: discord.VoiceState, after: discord.VoiceState):
    # 1. Logic Tạo phòng khi người dùng vào kênh Generator
    if after.channel and isinstance(after.channel, discord.VoiceChannel):
        row = get_generator(member.guild.id)
        if row and after.channel.id == row["generator_id"]:
            await create_room(member.guild, member)

    # 2. Logic Tự động Xóa phòng (Bỏ qua database, quét trực tiếp tên phòng)
    if before.channel and isinstance(before.channel, discord.VoiceChannel):
        row = get_generator(member.guild.id)
        
        # Không bao giờ xóa kênh Generator
        if row and before.channel.id == row["generator_id"]:
            return

        # Kiểm tra nếu phòng trống người VÀ tên phòng có chứa chữ 'Room' (hoặc 'room')
        if len(before.channel.members) == 0 and "room" in before.channel.name.lower():
            try:
                print(f"[DEBUG] Đang tiến hành xóa phòng trống: {before.channel.name}")
                await before.channel.delete(reason="TempVoice: Phòng trống")
                
                # Cố gắng xóa dữ liệu trong DB nếu có hàm
                if 'delete_room_record' in globals():
                    delete_room_record(before.channel.id)
            except Exception as e:
                print(f"[ERROR] Không thể xóa kênh: {e}")

    # Any room that became empty -> delete.
    if DELETE_EMPTY and before.channel and isinstance(before.channel, discord.VoiceChannel):
        room = get_room(before.channel.id)
        if room and len(before.channel.members) == 0:
            await delete_temp_room(before.channel)


if __name__ == "__main__":
    init_db()
    bot.run(TOKEN)
