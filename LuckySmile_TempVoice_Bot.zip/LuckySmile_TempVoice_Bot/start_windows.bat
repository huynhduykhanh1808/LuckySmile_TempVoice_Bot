@echo off
title Lucky Smile TempVoice
if not exist .venv (
    py -3.12 -m venv .venv
)
call .venv\Scripts\activate
python -m pip install -U pip
pip install -r requirements.txt
python bot.py
pause
