# Lucky Smile TempVoice

Bot Discord tạo Temporary Voice Channel kiểu Astro.

## Chức năng

- `/setup` tự tạo Category, Generator và kênh quản lý.
- Vào `➕・Tạo Phòng` → bot tự tạo room riêng và kéo bạn vào.
- Rời room, nếu room trống → bot tự xóa.
- `/room` → mở bảng điều khiển.
- Nút: đổi tên, giới hạn người, khóa/mở khóa, ẩn/hiện, chuyển chủ, xóa.
- `/room-kick`, `/room-allow`, `/room-deny`, `/room-reset`.
- SQLite lưu owner/room để bot không mất dữ liệu sau restart.
- Nếu bot restart, room còn tồn tại vẫn được nhận diện; room trống sẽ bị xóa khi event tiếp theo xảy ra.
- Có thể đổi tên Category/Generator/Control bằng `.env`.

## 1. Tạo Discord Bot

Vào Discord Developer Portal → tạo Application → Bot → Reset Token và copy token.

Khi mời bot vào server, bật:

### OAuth2 Scopes
- `bot`
- `applications.commands`

### Bot Permissions
Nên cấp:
- View Channels
- Send Messages
- Embed Links
- Read Message History
- Connect
- Speak
- Move Members
- Manage Channels

Không cần Administrator.

## 2. Cài Python

Khuyến nghị Python 3.11 hoặc 3.12.

Mở CMD trong thư mục bot:

```bat
py -3.12 -m venv .venv
.venv\Scripts\activate
python -m pip install -U pip
pip install -r requirements.txt
```

## 3. Tạo `.env`

Copy:

```text
.env.example
```

thành:

```text
.env
```

Sau đó sửa:

```env
DISCORD_TOKEN=TOKEN_CUA_BAN
```

Không gửi token cho người khác.

## 4. Chạy bot

```bat
python bot.py
```

Nếu thấy:

```text
Đăng nhập: Lucky Smile ...
Đã sync ... slash commands.
```

là bot đã chạy.

## 5. Setup server

Trong Discord dùng:

```text
/setup
```

Bot sẽ tạo:

```text
🎙️・Lucky Smile Rooms
├── ➕・Tạo Phòng
├── 🎛️・quản-lý-phòng
└── 🔊 ... (temporary rooms)
```

Sau đó vào `➕・Tạo Phòng`.

## 6. Nếu bot không tạo room

Kiểm tra role của bot:

- View Channel = Allow
- Manage Channels = Allow
- Connect = Allow
- Speak = Allow
- Move Members = Allow

Quan trọng nhất là `Manage Channels` và `Move Members`.

Ngoài ra, role của bot phải nằm đủ cao để Discord cho phép bot thực hiện các permission overwrite cần thiết.

## 7. Lưu ý

- Token chỉ nằm trong `.env`, không commit lên GitHub.
- Không đặt bot token trực tiếp trong `bot.py`.
- Nếu muốn bot chạy 24/7, chạy trên VPS hoặc máy tính luôn bật.
- Nếu đổi Category/Generator thủ công, dùng `/setup` để đồng bộ lại.
